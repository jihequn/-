<template>
  <div id="app">
    <el-form :inline="true" :model="formInline" :rules="rules" class="demo-form-inline">
      <el-form-item label="审批人" prop="user">
        <el-input v-model="formInline.user" placeholder="审批人"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="onSubmit">查询</el-button>
      </el-form-item>
    </el-form>

    <br>
    <auto-form :model="formInline" :rules="rules">
      <auto-form-item label="审批人" prop="user">
        <auto-input v-model="formInline.user" placeholder="审批人"></auto-input>
      </auto-form-item>
    </auto-form>
  </div>
</template>

<script>
import autoForm from "./components/auto-form.vue";
import autoFormItem from "./components/auto-form-item.vue";
import autoInput from "./components/auto-input.vue";

export default {
  name: "app",
  data() {
    return {
      formInline: {
        user: "me",
        region: ""
      },
      rules:{
         user:[{ required: true, message: '请输入活动名称', trigger: 'blur' }]
      }
    };
  },
  methods: {
    onSubmit() {
      console.log("submit!");
    }
  },
  components: {
    autoForm,
    autoFormItem,
    autoInput
  }
};
</script>

<style>
#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
