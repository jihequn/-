<template>
  <form class="el-form el-form--inline">
    <slot></slot>
  </form>
</template>

<script>
export default {
  name: "autoForm",
  componentName: "autoForm",
  provide() {
    return {
      autoForm: this
    };
  },
  props: {
    model: Object,
    rules: Object,
  },
  // 通过在Form中监听事件来完成数据的存放与删除
  data() {
    return {
      fields: []
    };
  },
  methods: {
  },
  created() {
    // 监听'el.form.addField
    // 当触发该事件时, 为fields数组添加form-item实例
    this.$on("el.form.addField", field => {
      if (field) {
        this.fields.push(field);
      }
    });
  }
};
</script>

</style>
