<template>
  <div class="el-input">
    <input
      class="el-input__inner"
      v-bind="$attrs"
      @compositionstart="handleCompositionStart"
      @compositionend="handleCompositionEnd"
      @input="handleInput"
      @blur="handleBlur"
    >
  </div>
</template>

<script>
import emitter from "../emitter";
export default {
  name: "autoInput",
  componentName: "autoInput",
  mixins: [emitter],
  inject: ["autoFormItem", "autoForm"],
  //inheritAttrs：默认值true,在这种情况下父作用域的不被认作 props 的特性绑定 (attribute bindings) 将会“回退”且作为普通的 HTML 特性应用在子组件的根元素上
  //$attr：包含了父作用域中不作为 prop 被识别 (且获取) 的特性绑定 (class 和 style 除外)
  inheritAttrs: false,
  created() {
    // console.log(this.$attrs);
    // console.log('autoform', this.autoForm);
  },
  props: {},
  methods: {
    handleCompositionStart() {
      this.isComposing = true;
    },
    handleCompositionEnd(event) {
      this.isComposing = false;
      this.handleInput(event);
    },
    handleInput(event) {
      if (this.isComposing) return;
      this.$emit("input", event.target.value);
    },
    handleBlur(event) {
      this.$emit("blur", event);
      this.dispatch("autoFormItem", "el.form.blur", [this.value]);
    }
  }
};
</script>

</style>
