<template>
  <div>
    <label class="el-form-item__label">{{label}}</label>
    <div class="el-form-item__content">
      <slot></slot>
      <div class="el-form-item__error" v-if="validateState">{{validateMessage}}</div>
    </div>
  </div>
</template>

<script>
import emitter from "../emitter";
import { noop, getPropByPath } from "../util";
export default {
  name: "autoFormItem",
  componentName: "autoFormItem",
  provide() {
    return {
      autoFormItem: this
    };
  },
  inject: ["autoForm"],
  mixins: [emitter],
  props: {
    label: {
      type: String,
      default: ""
    },
    prop: {
      type: String
    }
  },
  data() {
    return {
      validateState: "",
      validateMessage: ""
    };
  },
  methods: {
    onFieldBlur() {
      alert(1);
      this.validate("blur");
    },
    validate(trigger, callback = noop) {
      console.log(this.getFilteredRule())
      // this.validateDisabled = false;
      // const rules = this.getFilteredRule(trigger);
      // if ((!rules || rules.length === 0) && this.required === undefined) {
      //   callback();
      //   return true;
      // }
      // this.validateState = "validating";
      // const descriptor = {};
      // if (rules && rules.length > 0) {
      //   rules.forEach(rule => {
      //     delete rule.trigger;
      //   });
      // }
      // descriptor[this.prop] = rules;
      // const validator = new AsyncValidator(descriptor);
      // const model = {};
      // model[this.prop] = this.fieldValue;
      // validator.validate(
      //   model,
      //   { firstFields: true },
      //   (errors, invalidFields) => {
      //     this.validateState = !errors ? "success" : "error";
      //     this.validateMessage = errors ? errors[0].message : "";
      //     callback(this.validateMessage, invalidFields);
      //     this.elForm &&
      //       this.elForm.$emit(
      //         "validate",
      //         this.prop,
      //         !errors,
      //         this.validateMessage || null
      //       );
      //   }
      // );
    },
    getRules() {
      let formRules = this.$parent.rules;

      const prop = getPropByPath(formRules, this.prop || "");
      formRules = formRules ? prop.o[this.prop || ""] || prop.v : [];
      return [].concat(formRules || []);
    },
    getFilteredRule(trigger) {
      const rules = this.getRules();
      console.log(rules);
      // return rules
      //   .filter(rule => {
      //     if (!rule.trigger || trigger === "") return true;
      //     if (Array.isArray(rule.trigger)) {
      //       return rule.trigger.indexOf(trigger) > -1;
      //     } else {
      //       return rule.trigger === trigger;
      //     }
      //   })
      //   .map(rule => objectAssign({}, rule));
    }
  },
  mounted() {
    // 如果定义了需要验证的字段
    if (this.prop) {
      // 向父亲Form组件添加filed
      //this.dispatch("autoForm", "el.form.addField", [this])
      // console.log('parent',this.$parent)
      this.$parent.$emit("el.form.addField", [this]);
      this.$on("el.form.blur", this.onFieldBlur);
    }
  }
};
</script>

</style>
